function makeBet() {
  alert('Ставка сделана! (заглушка)');
}
function recharge() {
  window.open('https://t.me/CryptoBot?start=crypto_pay_440515_AAY96bVPxmRJMesewJALR24lNrfaNaFC99Y', '_blank');
}
function withdraw() {
  alert('Вывод доступен на Душанбе Сити и Alif (от 50 сомони)');
}
function openHistory() {
  alert('Здесь будет история ваших ставок');
}
function openSupport() {
  window.open('https://wa.me/992000307112', '_blank');
}